<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Form</title>
    <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
   <div class="container">
   <div class="row mt-5 justify-content-center">
    <div class="col-lg-6">
        <div class="card card-primary">
            <div class="card-header">
                <h2>PHP Form</h2>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="mb-3">
                        <label>Name</label>
                        <input type="text"name="name"class="form-control"placeholder="Input Name">
                    </div>
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="text"name="email"class="form-control"placeholder="Input Email">
                    </div>
                    <div class="mb-3">
                        <label>Phone</label>
                        <input type="text"name="phone"class="form-control"placeholder="Input Phone">
                    </div>
                    <div class="mb-3">
                        <label>Gender</label>
                        </div>  
                       <div class="form-check form-check-inline">
                        <input type="radio"name="gender"value="Male"class="form-check-input">
                        <label >Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                        <input type="radio"name="gender"value="Male"class="form-check-input">
                        <label >Female</label>
                        </div>

                    </div>
                    <div class="mb-3">
                        <label>Adress</label>
                    <textarea class="form-control" name="address"></textarea>
                    </div>
                    <div class="d-grid">
                        <input type="submit"class="btn btn-success">
                    </div>

                </form>
            </div>

        </div>

    </div>

   </div>

   </div>
</body>
</html>

<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];

    echo "Name: ".$name."<br>";
    echo "Email: ".$email."<br>";
    echo "Phone: ".$phone."<br>";
    echo "Gender: ".$gender."<br>";
    echo "Address: ".$address."<br>";
}

?>